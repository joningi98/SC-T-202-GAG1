create function make_new_account(n_abalance integer, n_aover integer, n_paname character varying, n_pgender character varying, n_pheigt double precision) returns void
  language plpgsql
as
$$
DECLARE
    newPID INTEGER;
BEGIN
     INSERT INTO people(pname, pgender, pheight)
     VALUES (n_paname, n_pgender, n_pheigt);
     newPID := lastval();
     insert into accounts(pid,adate, abalance, aover)
     VALUES (newPID, current_date, n_abalance, n_aover);
     RETURN;
END;
$$;

alter function make_new_account(integer, integer, varchar, varchar, double precision) owner to postgres;

