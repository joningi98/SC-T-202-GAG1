create procedure check_accounts()
  language plpgsql
as
$$
BEGIN
  PERFORM *
  FROM accounts A
  WHERE (A.abalance != 0 OR
         EXISTS( SELECT * FROM accountrecords R1
           WHERE A.aid = R1.aid))
  AND NOT EXISTS( SELECT * FROM accountrecords R
    WHERE A.aid = R.aid
    AND A.adate = R.rdate
    AND A.abalance = R.rbalance
    AND R.aid = (SELECT MAX(r2.rid) FROM accountrecords r2
    WHERE r2.aid = a.aid));
  RETURN;
END
$$;

alter procedure check_accounts() owner to postgres;

