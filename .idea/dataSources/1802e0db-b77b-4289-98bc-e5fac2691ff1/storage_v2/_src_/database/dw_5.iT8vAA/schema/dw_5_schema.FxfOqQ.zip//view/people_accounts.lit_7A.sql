create view people_accounts as
SELECT p.pid,
       p.pname,
       p.pgender,
       p.pheight,
       a2.rid,
       a2.aid,
       a2.rdate,
       a2.rtype,
       a2.ramount,
       a2.rbalance
FROM ((dw_5_schema.people p
  JOIN dw_5_schema.accounts a ON ((p.pid = a.pid)))
       JOIN dw_5_schema.accountrecords a2 ON ((a.aid = a2.aid)));

alter table people_accounts
  owner to postgres;

