create function check_people_insert() returns trigger
  language plpgsql
as
$$
BEGIN
    IF (NEW.pgender != 'M' or NEW.pgender != 'F' or NEW.pheight < 0) THEN
      RAISE EXCEPTION 'Wrong input';
    END IF;
      RETURN NEW;
END
$$;

alter function check_people_insert() owner to postgres;

