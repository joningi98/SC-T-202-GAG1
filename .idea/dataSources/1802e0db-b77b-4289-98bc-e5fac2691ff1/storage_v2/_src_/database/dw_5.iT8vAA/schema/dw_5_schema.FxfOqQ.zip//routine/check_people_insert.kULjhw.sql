create function check_people_insert() returns trigger
  language plpgsql
as
$$
BEGIN
    IF people.pgender = 'M' or people.pgender = 'F' or people.pheight > 0 THEN
      INSERT INTO people(pname, pgender, pheight)
      VALUES(NEW.pname, NEW.pgender, NEW.pheight);
    end if;

    RETURN NEW;
END
$$;

alter function check_people_insert() owner to postgres;

