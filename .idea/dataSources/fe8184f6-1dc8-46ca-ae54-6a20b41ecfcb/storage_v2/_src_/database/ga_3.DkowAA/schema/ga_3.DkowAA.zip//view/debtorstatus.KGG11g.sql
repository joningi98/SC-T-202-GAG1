create view debtorstatus as
SELECT DISTINCT p.pid,
                p.pname,
                a.abalance
FROM (ga_3.people p
       JOIN ga_3.accounts a ON ((p.pid = a.pid)))
WHERE (a.abalance < 0)
GROUP BY p.pid, a.abalance;

alter table debtorstatus
  owner to postgres;

