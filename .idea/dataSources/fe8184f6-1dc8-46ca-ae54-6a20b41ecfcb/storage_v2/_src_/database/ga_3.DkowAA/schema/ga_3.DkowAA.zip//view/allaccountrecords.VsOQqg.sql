create view allaccountrecords as
SELECT a.aid,
       a.pid,
       a.adate,
       a.abalance,
       a.aover,
       a2.rid,
       a2.rdate,
       a2.rtype,
       a2.ramount,
       a2.rbalance
FROM (ga_3.accounts a
       LEFT JOIN ga_3.accountrecords a2 ON ((a.aid = a2.aid)));

alter table allaccountrecords
  owner to postgres;

