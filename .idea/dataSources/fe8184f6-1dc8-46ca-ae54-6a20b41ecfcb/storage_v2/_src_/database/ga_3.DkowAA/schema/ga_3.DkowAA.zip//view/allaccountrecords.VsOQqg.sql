create view allaccountrecords as
SELECT a.aid,
       a.pid,
       a.adate,
       a.abalance,
       a.aover
FROM ga_3.accounts a,
     ga_3.accountrecords ar
WHERE (a.aid IN (SELECT ar2.aid
                 FROM ga_3.accountrecords ar2))
GROUP BY a.pid, a.aid;

alter table allaccountrecords
  owner to postgres;

