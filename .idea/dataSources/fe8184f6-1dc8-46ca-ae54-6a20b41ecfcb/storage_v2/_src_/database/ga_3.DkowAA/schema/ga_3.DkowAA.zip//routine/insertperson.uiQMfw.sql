create function insertperson(iname character varying, igender character varying, iheight double precision) returns void
  language plpgsql
as
$$
BEGIN
    INSERT INTO people (pname, pgender, pheight) VALUES (iName, iGender, iHeight);
  end;
$$;

alter function insertperson(varchar, varchar, double precision) owner to postgres;

