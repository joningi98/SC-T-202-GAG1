create function loanmoney(iaid integer, iamount integer, iduedate date) returns void
  language plpgsql
as
$$
DECLARE LONEE_ID INT;
  BEGIN
    LONEE_ID := (SELECT p.pid
                 FROM people p
                 INNER JOIN accounts a ON a.pid = p.pid
                 WHERE a.aid = iAID);

    INSERT INTO bills (pid, bduedate, bamount, bispaid) VALUES (LONEE_ID, iDueDate, iAmount, 'F');
    UPDATE accounts SET abalance = abalance + iAmount WHERE aid = iAID;
  end;
$$;

alter function loanmoney(integer, integer, date) owner to postgres;

