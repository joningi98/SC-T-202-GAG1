create function startnewaccount() returns trigger
  language plpgsql
as
$$
DECLARE NEW_PID INT;
  BEGIN
    NEW_PID := lastval();
    INSERT INTO accounts (pid, adate, abalance, aover) VALUES (NEW_PID, current_date, 1000, 0);
    RETURN NEW;
  end;
$$;

alter function startnewaccount() owner to postgres;

