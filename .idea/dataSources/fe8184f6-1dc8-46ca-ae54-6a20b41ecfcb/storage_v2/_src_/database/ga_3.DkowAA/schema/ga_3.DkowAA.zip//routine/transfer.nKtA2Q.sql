create function transfer(itoaid integer, ifromaid integer, iamount integer) returns void
  language plpgsql
as
$$
BEGIN
    INSERT INTO accountrecords (aid, rdate, rtype, ramount, rbalance) VALUES (iFromAID, current_date, 'T', iAmount, ((SELECT abalance
                                                                                                                     FROM accounts a
                                                                                                                     INNER JOIN people p on a.pid = p.pid
                                                                                                                     WHERE a.aid = iFromAID) - iAmount));
    INSERT INTO accountrecords (aid, rdate, rtype, ramount, rbalance) VALUES (iToAID, current_date, 'T', iAmount, ((SELECT abalance
                                                                                                                     FROM accounts a
                                                                                                                     INNER JOIN people p on a.pid = p.pid
                                                                                                                     WHERE a.aid = iToAID) + iAmount));
    UPDATE accounts SET abalance = abalance - iAmount WHERE aid = iFromAID;
    UPDATE accounts SET abalance = abalance + iAmount WHERE aid = iToAID;
  end;
$$;

alter function transfer(integer, integer, integer) owner to postgres;

