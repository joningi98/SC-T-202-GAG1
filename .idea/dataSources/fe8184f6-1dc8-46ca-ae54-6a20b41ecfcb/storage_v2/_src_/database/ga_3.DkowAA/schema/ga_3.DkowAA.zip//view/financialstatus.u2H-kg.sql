create view financialstatus as
SELECT p.pid,
       p.pname,
       sum(a.abalance) AS total_balance,
       sum(b.bamount)  AS unpaid
FROM ((ga_3.people p
  JOIN ga_3.accounts a ON ((p.pid = a.pid)))
       JOIN ga_3.bills b ON ((p.pid = b.pid)))
WHERE (b.bispaid = false)
GROUP BY p.pid
HAVING (count(a.pid) > 1);

alter table financialstatus
  owner to postgres;

