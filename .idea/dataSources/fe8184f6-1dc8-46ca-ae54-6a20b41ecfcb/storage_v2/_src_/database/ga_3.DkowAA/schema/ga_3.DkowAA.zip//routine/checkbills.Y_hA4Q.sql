create function checkbills() returns trigger
  language plpgsql
as
$$
BEGIN
    IF( NEW.bduedate < CURRENT_DATE) THEN
      RAISE EXCEPTION 'Due date cant be later than today´s date' USING ERRCODE = '45000';
    end if;
    IF (NEW.bamount < 0) THEN
      RAISE EXCEPTION 'Bills cannot have a negative amount' USING ERRCODE = '45000';
    end if;
    IF (TG_OP = 'DELETE') THEN
      RAISE EXCEPTION 'Cannot delete' USING ERRCODE = '45000';
    end if;
    IF (TG_OP = 'UPDATE') THEN
        IF (bispaid = 'T') THEN
          RAISE EXCEPTION 'Cannot change ' USING ERRCODE = '45000';
        end if;
    END IF;
    RETURN NEW;
  end;
$$;

alter function checkbills() owner to postgres;

